#. There's a **Chatter Position** option in **User Preferences**, where you can
choose between ``auto``, ``bottom`` and ``sided``.
