This module is based on the Instant Messaging Bus. To work properly, the server must be launched in gevent mode.
