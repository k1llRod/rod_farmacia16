* Allow to click on the whole line (not just the checkbox) to select a row.
* Enable the same behaviour with Ctrl button.
* Shift and drag to select rows.
