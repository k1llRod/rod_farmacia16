The standard grants/prevents access to any UI export via *Access to export feature*
group.

This module adds a new group for the 'Direct Export (xlsx)' feature, leaving the
standard one for only the 'Export All' feature.

Admin users can always use the export option.
