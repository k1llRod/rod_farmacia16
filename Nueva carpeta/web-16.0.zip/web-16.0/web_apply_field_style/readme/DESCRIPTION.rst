Allow to set an additional css class to fields in form view.

Use case : you may highlight some fields for training purpose

.. figure:: ../static/description/demo.png
    :alt: Colored fields
