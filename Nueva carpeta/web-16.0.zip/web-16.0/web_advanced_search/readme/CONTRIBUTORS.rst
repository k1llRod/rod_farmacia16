* Holger Brunn <hbrunn@therp.nl>
* Rami Alwafaie <rami.alwafaie@initos.com>
* Jose Mª Bernet <josemaria.bernet@guadaltech.es>
* Simone Orsi <simone.orsi@camptocamp.com>
* Dennis Sluijk <d.sluijk@onestein.nl>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Vicent Cubells
  * Jairo Llopis
  * Alexandre Díaz

* `DynApps NV <https://www.dynapps.be>`_:

  * Raf Ven

* `Camptocamp <https://www.camptocamp.com>`_

    * Iván Todorovich <ivan.todorovich@camptocamp.com>
