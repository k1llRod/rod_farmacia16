* Cristian Salamea <cristian.salamea@gmail.com>
* André Paramés <github@andreparames.com> (https://www.acsone.eu/)
* Alexandre Díaz <alexandre.diaz@tecnativa.com>
* Sudhir Arya <sudhir@erpharbor.com>
* Jasper Jumelet <jasper.jumelet@codeforward.nl>
* `Trobz <https://trobz.com>`_:
    * Nguyễn Minh Chiến <chien@trobz.com>
