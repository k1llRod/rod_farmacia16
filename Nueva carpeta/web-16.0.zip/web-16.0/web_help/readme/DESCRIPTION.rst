This module introduces a new way to guide the user through Odoo.
This module is created because **the standard Odoo tours:**

#. forces the user to create records;
#. cannot be reopened;
#. is only available for the admin user;
#. the bubbles are not obvious.
