This module will send an instant notifications to all users of a channel when a new message has been posted.
