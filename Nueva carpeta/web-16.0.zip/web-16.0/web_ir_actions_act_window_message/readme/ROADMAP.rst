* add `message_type` to differenciate between warnings, errors, etc.
* have one `message_type` to show a nonmodal warning on top right
