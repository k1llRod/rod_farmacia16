.. warning::
    This module is deprecated.
    If you want to use this functionality you can assign a unserialised
    domain to a fields.Binary, `example <https://github.com/OCA/OCB/blob/16.0/addons/account/models/account_tax.py#L1308>`_

This technical addon allows developers to specify a field domain in a view
using the value of another field in that view, rather than as a static
XML attribute.
