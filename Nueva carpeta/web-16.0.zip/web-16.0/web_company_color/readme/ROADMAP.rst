White color is omitted in the addition operation to support images without alpha channel.
