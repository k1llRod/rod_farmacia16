Adds support for computed measures on the pivot view.
